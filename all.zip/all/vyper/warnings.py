# TODO: Create VyperWarning class similarly to what is being done with exceptinos?
class ContractSizeLimitWarning(Warning):
    pass
