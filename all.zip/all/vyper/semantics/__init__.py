from .analysis import analyze_module, validate_compilation_target
from .analysis.data_positions import set_data_positions
